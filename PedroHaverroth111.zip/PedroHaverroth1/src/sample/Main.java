package sample;

import sample.model.Produto;

public class Main {
    public static void main(String[] args) {

        Produto produto = new Produto();
        produto.setNome("Barra de chocolate");
        produto.setPreco(5.99);

        produto Produto = new Produto();
        produto.setNome("Suco tang");
        produto.setPreco(1.25);
    }
}

