package sample.model;

public class Professor {
    private String salario;}

