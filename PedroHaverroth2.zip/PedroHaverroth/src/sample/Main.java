package sample;

import sample.model.Pessoal;
import sample.model.Aluno;
import sample.model.Endereco;

public class Main {

    public static void main(String[] args){

        Pessoal pessoal = new Pessoal();
        pessoal.setNome("julia");
        pessoal.setTelefone("48991149613");
        pessoal.setEmail("juliasim@gmail.com");

        Pessoal pessoal = new Pessoal();
        pessoal.setNome("Igor");
        pessoal.setTelefone("47998743564");
        pessoal.setEmail("igorjuliano@gmail.com");

        Aluno aluno = new Aluno();
        aluno.setMatricula("9876545");
        aluno.setMedia("6.5");

        Endereco endereco = new Endereco();
        endereco.setCep("98765678");
        endereco.setCidade("Florianópolis");
        endereco.setRua("rua das gaivotas");
        endereco.setUf("SC");
        endereco.setPais("Brasil");

    }
}
